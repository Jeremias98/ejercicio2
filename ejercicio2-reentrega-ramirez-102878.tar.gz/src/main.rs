use ejercicio2::run;

fn main() -> Result<(), String> {
    run()
}
